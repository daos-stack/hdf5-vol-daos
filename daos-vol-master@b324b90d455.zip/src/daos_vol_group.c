/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of the HDF5 DAOS VOL connector. The full copyright      *
 * notice, including terms governing use, modification, and redistribution,  *
 * is contained in the COPYING file, which can be found at the root of the   *
 * source code distribution tree.                                            *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
 * Purpose: The DAOS VOL connector where access is forwarded to the DAOS
 * library. Group routines.
 */

#include "daos_vol.h"           /* DAOS connector                          */

#include "util/daos_vol_err.h"  /* DAOS connector error handling           */
#include "util/daos_vol_mem.h"  /* DAOS connector memory management        */

/************************************/
/* Local Type and Struct Definition */
/************************************/

/* User data struct for group get info */
typedef struct H5_daos_group_get_info_ud_t {
    H5_daos_req_t *req;
    H5G_info_t *group_info;
    H5_daos_obj_t *target_obj;
    H5I_type_t opened_type;
} H5_daos_group_get_info_ud_t;

/* User data struct for group get num links */
typedef struct H5_daos_group_gnl_ud_t {
    H5_daos_md_rw_cb_ud_t md_rw_cb_ud; /* Must be first */
    uint8_t nlinks_buf[H5_DAOS_ENCODED_NUM_LINKS_SIZE];
    tse_task_t *gnl_task;
    hsize_t *nlinks;
} H5_daos_group_gnl_ud_t;

/* User data struct for group get max creation order */
typedef struct H5_daos_group_gmco_ud_t {
    H5_daos_md_rw_cb_ud_t md_rw_cb_ud;
    uint8_t max_corder_buf[H5_DAOS_ENCODED_CRT_ORDER_SIZE];
    uint64_t *max_corder;
} H5_daos_group_gmco_ud_t;

/********************/
/* Local Prototypes */
/********************/

static herr_t H5_daos_group_fill_gcpl_cache(H5_daos_group_t *grp);
static int H5_daos_group_open_bcast_comp_cb(tse_task_t *task, void *args);
static int H5_daos_group_open_recv_comp_cb(tse_task_t *task, void *args);
static int H5_daos_group_get_info_task(tse_task_t *task);
static herr_t H5_daos_group_get_info(H5_daos_group_t *grp, const H5VL_loc_params_t *loc_params,
    H5G_info_t *group_info, H5_daos_req_t *req, tse_task_t **first_task,
    tse_task_t **dep_task);
static int H5_daos_group_gnl_task(tse_task_t *task);
static int H5_daos_group_gnl_comp_cb(tse_task_t *task, void *args);
static int H5_daos_group_gmco_comp_cb(tse_task_t *task, void *args);


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_traverse
 *
 * Purpose:     Given a path name and base object, returns the final group
 *              in the path and the object name.  obj_name points into the
 *              buffer given by path, so it does not need to be freed.
 *              The group must be closed with H5_daos_group_close().
 *
 * Return:      Success:        group object. 
 *              Failure:        NULL
 *
 * Programmer:  Neil Fortner
 *              December, 2016
 *
 *-------------------------------------------------------------------------
 */
H5_daos_obj_t *
H5_daos_group_traverse(H5_daos_item_t *item, const char *path,
    hid_t lcpl_id, H5_daos_req_t *req, hbool_t collective, char **path_buf,
    const char **obj_name, size_t *obj_name_len, tse_task_t **first_task,
    tse_task_t **dep_task)
{
    H5_daos_obj_t *obj = NULL;
    char *tmp_path_buf = NULL;
    H5_daos_obj_t *ret_value = NULL;

    assert(item);
    assert(path);
    assert(req);
    assert(path_buf);
    assert(!*path_buf);
    assert(obj_name);
    assert(obj_name_len);
    assert(first_task);
    assert(dep_task);

    /* Initialize obj_name */
    *obj_name = path;

    /* Open starting group */
    if((*obj_name)[0] == '/') {
        obj = &item->file->root_grp->obj;
        (*obj_name)++;
    } /* end if */
    else {
        if(item->type == H5I_FILE)
            obj = &((H5_daos_file_t *)item)->root_grp->obj;
        else
            obj = (H5_daos_obj_t *)item;
    } /* end else */
    obj->item.rc++;

    /* Strip trailing no-op components of path ("/" and "/.") */
    *obj_name_len = strlen(*obj_name);
    while(*obj_name_len > 0)
        if((*obj_name)[*obj_name_len - 1] == '/')
            (*obj_name_len)--;
        else if((*obj_name)[*obj_name_len - 1] == '.') {
            if(*obj_name_len == 1)
                (*obj_name_len) = 0;
            else if((*obj_name)[*obj_name_len - 2] == '/')
                (*obj_name_len) -= 2;
            else
                break;
        } /* end if */
        else
            break;

    /* Traverse path if this process should */
    if((!collective || (item->file->my_rank == 0)) && (*obj_name_len > 0)) {
        const char *next_obj;
        unsigned crt_intermed_grp = 0;

        /* Make sure obj is a group */
        if(obj->item.type != H5I_GROUP)
            D_GOTO_ERROR(H5E_ARGS, H5E_BADTYPE, NULL, "cannot initiate traversal from non-group object");

        /* Determine if intermediate groups should be created */
        if((H5P_LINK_CREATE_DEFAULT != lcpl_id) && H5Pget_create_intermediate_group(lcpl_id, &crt_intermed_grp) < 0)
            D_GOTO_ERROR(H5E_PLIST, H5E_CANTGET, NULL, "can't get intermediate group creation property value");

        /* Create copy of path for use by async tasks and make obj_name point
         * into it */
        if(NULL == (tmp_path_buf = DV_malloc(*obj_name_len + 1)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTALLOC, NULL, "can't allocate space for path");
        memcpy(tmp_path_buf, *obj_name, *obj_name_len);
        tmp_path_buf[*obj_name_len] = '\0';
        *obj_name = tmp_path_buf;

        /* Search for '/' */
        next_obj = strchr(*obj_name, '/');

        /* Traverse path */
        while(next_obj) {
            daos_obj_id_t **oid_ptr;
            ptrdiff_t component_len;

            /* Calculate length of path component */
            component_len = next_obj - *obj_name;

            /* Advance obj_name_len to match next_obj */
            *obj_name_len -= (size_t)(component_len + 1);

            /* Skip past "." path element */
            if(!(component_len == 1 && (*obj_name)[0] == '.')) {
                /* Follow link to next group in path */
                assert(next_obj > *obj_name);
                assert(obj->item.type == H5I_GROUP);
                if(H5_daos_link_follow((H5_daos_group_t *)obj, *obj_name, (size_t)component_len,
                        (hbool_t)crt_intermed_grp, req, &oid_ptr, NULL, first_task, dep_task) < 0)
                    D_GOTO_ERROR(H5E_SYM, H5E_TRAVERSE, NULL, "can't follow link to group");

                /* Close previous group */
                if(H5_daos_group_close((H5_daos_group_t *)obj, req->dxpl_id, NULL) < 0)
                    D_GOTO_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close group");
                obj = NULL;

                /* Open next group in path */
                if(NULL == (obj = (H5_daos_obj_t *)H5_daos_group_open_helper(item->file,
                        H5P_GROUP_ACCESS_DEFAULT, FALSE, req, first_task, dep_task)))
                    D_GOTO_ERROR(H5E_SYM, H5E_CANTOPENOBJ, NULL, "can't open group");

                /* Retarget oid_ptr to grp->obj.oid so H5_daos_link_follow fills in
                 * the group's oid */
                *oid_ptr = &obj->oid;
            } /* end if */

            /* Advance to next path element */
            *obj_name = next_obj + 1;
            next_obj = strchr(*obj_name, '/');
        } /* end while */

        /* Set path_buf */
        *path_buf = tmp_path_buf;
        tmp_path_buf = NULL;

        assert(*obj_name_len == strlen(*obj_name));
        assert(*obj_name_len > 0);
    } /* end if */

    /* Set return value */
    ret_value = obj;

done:
    /* Cleanup on failure */
    if(NULL == ret_value) {
        /* Close group */
        if(obj && H5_daos_object_close(obj, req->dxpl_id, NULL) < 0)
            D_DONE_ERROR(H5E_FILE, H5E_CLOSEERROR, NULL, "can't close object");

        /* Free memory */
        tmp_path_buf = DV_free(tmp_path_buf);
    } /* end if */

    /* Make sure we cleaned up */
    assert(!tmp_path_buf);

    D_FUNC_LEAVE;
} /* end H5_daos_group_traverse() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_fill_gcpl_cache
 *
 * Purpose:     Fills the "gcpl_cache" field of the group struct, using
 *              the group's GCPL.  Assumes grp->gcpl_cache has been
 *              initialized to all zeros.
 *
 * Return:      Success:        0
 *              Failure:        -1
 *
 * Programmer:  Neil Fortner
 *              August, 2019
 *
 *-------------------------------------------------------------------------
 */
static herr_t
H5_daos_group_fill_gcpl_cache(H5_daos_group_t *grp)
{
    unsigned corder_flags;
    herr_t ret_value = SUCCEED;

    assert(grp);

    /* Determine if this group is tracking link creation order */
    if(H5Pget_link_creation_order(grp->gcpl_id, &corder_flags) < 0)
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't get link creation order flags");
    assert(!grp->gcpl_cache.track_corder);
    if(corder_flags & H5P_CRT_ORDER_TRACKED)
        grp->gcpl_cache.track_corder = TRUE;

done:
    D_FUNC_LEAVE;
} /* end H5_daos_group_fill_gcpl_cache() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_create_helper
 *
 * Purpose:     Performs the actual group creation.
 *
 * Return:      Success:        group object. 
 *              Failure:        NULL
 *
 * Programmer:  Neil Fortner
 *              November, 2016
 *
 *-------------------------------------------------------------------------
 */
void *
H5_daos_group_create_helper(H5_daos_file_t *file, hbool_t is_root,
    hid_t gcpl_id, hid_t gapl_id, H5_daos_group_t *parent_grp, const char *name,
    size_t name_len, hbool_t collective, H5_daos_req_t *req,
    tse_task_t **first_task, tse_task_t **dep_task)
{
    H5_daos_group_t *grp = NULL;
    void *gcpl_buf = NULL;
    H5_daos_md_rw_cb_ud_t *update_cb_ud = NULL;
    tse_task_t *group_metatask;
    int gmt_ndeps = 0;
    tse_task_t *gmt_deps[2];
    int ret;
    void *ret_value = NULL;

    assert(file);
    assert(file->flags & H5F_ACC_RDWR);
    assert(first_task);
    assert(dep_task);

    /* Allocate the group object that is returned to the user */
    if(NULL == (grp = H5FL_CALLOC(H5_daos_group_t)))
        D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "can't allocate DAOS group struct");
    grp->obj.item.type = H5I_GROUP;
    grp->obj.item.open_req = req;
    req->rc++;
    grp->obj.item.file = file;
    grp->obj.item.rc = 1;
    grp->obj.obj_oh = DAOS_HDL_INVAL;
    grp->gcpl_id = H5I_INVALID_HID;
    grp->gapl_id = H5I_INVALID_HID;

    if(is_root) {
        /* Encode root group oid */
        if(H5_daos_oid_encode(&grp->obj.oid, H5_DAOS_OIDX_ROOT, H5I_GROUP,
                (gcpl_id == H5P_GROUP_CREATE_DEFAULT ? H5P_DEFAULT : gcpl_id),
                H5_DAOS_OBJ_CLASS_NAME, file) < 0)
            D_GOTO_ERROR(H5E_FILE, H5E_CANTENCODE, NULL, "can't encode object ID");
    }
    else {
        /* Generate an oid for the group */
        if(H5_daos_oid_generate(&grp->obj.oid, H5I_GROUP,
                (gcpl_id == H5P_GROUP_CREATE_DEFAULT ? H5P_DEFAULT : gcpl_id),
                file, collective, req, first_task, dep_task) < 0)
            D_GOTO_ERROR(H5E_DATASET, H5E_CANTINIT, NULL, "can't generate object id");
    }

    /* Open group object */
    if(H5_daos_obj_open(file, req, &grp->obj.oid, DAOS_OO_RW,
            &grp->obj.obj_oh, "group object open", first_task, dep_task) < 0)
        D_GOTO_ERROR(H5E_SYM, H5E_CANTOPENOBJ, NULL, "can't open group object");

    /* Create group and write metadata if this process should */
    if(!collective || (file->my_rank == 0)) {
        size_t gcpl_size = 0;
        tse_task_t *update_task;

        /* Create group */
        /* Allocate argument struct */
        if(NULL == (update_cb_ud = (H5_daos_md_rw_cb_ud_t *)DV_calloc(sizeof(H5_daos_md_rw_cb_ud_t))))
            D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "can't allocate buffer for update callback arguments");

        /* Encode GCPL */
        if(H5Pencode2(gcpl_id, NULL, &gcpl_size, file->fapl_id) < 0)
            D_GOTO_ERROR(H5E_ARGS, H5E_BADTYPE, NULL, "can't determine serialized length of gcpl");
        if(NULL == (gcpl_buf = DV_malloc(gcpl_size)))
            D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "can't allocate buffer for serialized gcpl");
        if(H5Pencode2(gcpl_id, gcpl_buf, &gcpl_size, file->fapl_id) < 0)
            D_GOTO_ERROR(H5E_SYM, H5E_CANTENCODE, NULL, "can't serialize gcpl");

        /* Set up operation to write GCPL to group */
        /* Point to grp */
        update_cb_ud->obj = &grp->obj;

        /* Point to req */
        update_cb_ud->req = req;

        /* Set up dkey.  Point to global name buffer, do not free. */
        daos_iov_set(&update_cb_ud->dkey, (void *)H5_daos_int_md_key_g, H5_daos_int_md_key_size_g);
        update_cb_ud->free_dkey = FALSE;

        /* Single iod and sgl */
        update_cb_ud->nr = 1u;

        /* Set up iod.  Point akey to global name buffer, do not free. */
        daos_iov_set(&update_cb_ud->iod[0].iod_name, (void *)H5_daos_cpl_key_g, H5_daos_cpl_key_size_g);
        update_cb_ud->iod[0].iod_nr = 1u;
        update_cb_ud->iod[0].iod_size = (uint64_t)gcpl_size;
        update_cb_ud->iod[0].iod_type = DAOS_IOD_SINGLE;
        update_cb_ud->free_akeys = FALSE;

        /* Set up sgl */
        daos_iov_set(&update_cb_ud->sg_iov[0], gcpl_buf, (daos_size_t)gcpl_size);
        update_cb_ud->sgl[0].sg_nr = 1;
        update_cb_ud->sgl[0].sg_nr_out = 0;
        update_cb_ud->sgl[0].sg_iovs = &update_cb_ud->sg_iov[0];

        /* Set task name */
        update_cb_ud->task_name = "group metadata write";

        /* Create task for group metadata write */
        assert(*dep_task);
        if(0 != (ret = daos_task_create(DAOS_OPC_OBJ_UPDATE, &file->sched, 1, dep_task, &update_task)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create task to write group medadata: %s", H5_daos_err_to_string(ret));

        /* Set callback functions for group metadata write */
        if(0 != (ret = tse_task_register_cbs(update_task, H5_daos_md_rw_prep_cb, NULL, 0, H5_daos_md_update_comp_cb, NULL, 0)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't register callbacks for task to write group medadata: %s", H5_daos_err_to_string(ret));

        /* Set private data for group metadata write */
        (void)tse_task_set_priv(update_task, update_cb_ud);

        /* Schedule group metadata write task and give it a reference to req and
         * the group */
        assert(*first_task);
        if(0 != (ret = tse_task_schedule(update_task, false)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't schedule task to write group metadata: %s", H5_daos_err_to_string(ret));
        req->rc++;
        grp->obj.item.rc++;
        update_cb_ud = NULL;
        gcpl_buf = NULL;

        /* Add dependency for group metatask */
        gmt_deps[gmt_ndeps] = update_task;
        gmt_ndeps++;

        /* Write link to group if requested */
        if(parent_grp) {
            H5_daos_link_val_t link_val;

            link_val.type = H5L_TYPE_HARD;
            link_val.target.hard = grp->obj.oid;
            link_val.target_oid_async = &grp->obj.oid;
            gmt_deps[gmt_ndeps] = *dep_task;
            if(0 != (ret = H5_daos_link_write(parent_grp, name, name_len,
                    &link_val, req, first_task, &gmt_deps[gmt_ndeps])))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create link to group: %s", H5_daos_err_to_string(ret));
            gmt_ndeps++;
        } /* end if */
        else if(!is_root) {
            /* No link to group and it's not the root group, write a ref count
             * of 0 to grp */
             gmt_deps[gmt_ndeps] = *dep_task;
            if(0 != (ret = H5_daos_obj_write_rc(NULL, &grp->obj, NULL, 0, &file->sched,
                    req, first_task, &gmt_deps[gmt_ndeps])))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't write object ref count: %s", H5_daos_err_to_string(ret));
            gmt_ndeps++;
        } /* end if */
    } /* end if */
    else {
        /* Note no barrier is currently needed here, daos_obj_open is a local
         * operation and can occur before the lead process writes metadata.  For
         * app-level synchronization we could add a barrier or bcast to the
         * calling functions (file_create, group_create) though it could only be
         * an issue with group reopen so we'll skip it for now.  There is
         * probably never an issue with file reopen since all commits are from
         * process 0, same as the group create above. */

        /* Add dependency for group metatask */
        assert(gmt_ndeps == 0);
        assert(*dep_task);
        gmt_deps[gmt_ndeps] = *dep_task;
        gmt_ndeps++;
        /* Check for failure of process 0 DSINC */
    } /* end else */

    /* Finish setting up group struct */
    if((grp->gcpl_id = H5Pcopy(gcpl_id)) < 0)
        D_GOTO_ERROR(H5E_SYM, H5E_CANTCOPY, NULL, "failed to copy gcpl");
    if((grp->gapl_id = H5Pcopy(gapl_id)) < 0)
        D_GOTO_ERROR(H5E_SYM, H5E_CANTCOPY, NULL, "failed to copy gapl");

    /* Fill GCPL cache */
    if(H5_daos_group_fill_gcpl_cache(grp) < 0)
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "failed to fill GCPL cache");

    /* Fill OCPL cache */
    if(H5_daos_fill_ocpl_cache(&grp->obj, grp->gcpl_id) < 0)
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "failed to fill OCPL cache");

    ret_value = (void *)grp;

done:
    /* Create metatask to use for dependencies on this group create */
    if(0 != (ret = tse_task_create(H5_daos_metatask_autocomplete, &file->sched, NULL, &group_metatask)))
        D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create meta task for group create: %s", H5_daos_err_to_string(ret));
    /* Register dependencies (if any) */
    else if(gmt_ndeps > 0 && 0 != (ret = tse_task_register_deps(group_metatask, gmt_ndeps, gmt_deps)))
        D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create dependencies for group meta task: %s", H5_daos_err_to_string(ret));
    /* Schedule group metatask (or save it to be scheduled later) */
    else {
        if(*first_task) {
            if(0 != (ret = tse_task_schedule(group_metatask, false)))
                D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't schedule group meta task: %s", H5_daos_err_to_string(ret));
            else
                *dep_task = group_metatask;
        } /* end if */
        else {
            *first_task = group_metatask;
            *dep_task = group_metatask;
        } /* end else */
    } /* end else */

    /* Cleanup on failure */
    /* Destroy DAOS object if created before failure DSINC */
    if(NULL == ret_value) {
        /* Close group */
        if(grp && H5_daos_group_close(grp, req->dxpl_id, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close group");

        /* Free memory */
        if(update_cb_ud && update_cb_ud->obj && H5_daos_object_close(update_cb_ud->obj, req->dxpl_id, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close object");
        gcpl_buf = DV_free(gcpl_buf);
        update_cb_ud = DV_free(update_cb_ud);
    } /* end if */

    assert(!update_cb_ud);
    assert(!gcpl_buf);

    D_FUNC_LEAVE;
} /* end H5_daos_group_create_helper() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_create
 *
 * Purpose:     Sends a request to DAOS to create a group
 *
 * Return:      Success:        group object. 
 *              Failure:        NULL
 *
 * Programmer:  Neil Fortner
 *              November, 2016
 *
 *-------------------------------------------------------------------------
 */
void *
H5_daos_group_create(void *_item,
    const H5VL_loc_params_t H5VL_DAOS_UNUSED *loc_params, const char *name,
    hid_t lcpl_id, hid_t gcpl_id, hid_t gapl_id, hid_t dxpl_id,
    void H5VL_DAOS_UNUSED **req)
{
    H5_daos_item_t *item = (H5_daos_item_t *)_item;
    H5_daos_group_t *grp = NULL;
    H5_daos_obj_t *target_obj = NULL;
    char *path_buf = NULL;
    const char *target_name = NULL;
    size_t target_name_len = 0;
    hbool_t collective;
    H5_daos_req_t *int_req = NULL;
    tse_task_t *first_task = NULL;
    tse_task_t *dep_task = NULL;
    int ret;
    void *ret_value = NULL;

    if(!_item)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, NULL, "group parent object is NULL");
    if(!loc_params)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, NULL, "location parameters object is NULL");

    /* Check for write access */
    if(!(item->file->flags & H5F_ACC_RDWR))
        D_GOTO_ERROR(H5E_FILE, H5E_BADVALUE, NULL, "no write intent on file");
 
    /*
     * Like HDF5, all metadata writes are collective by default. Once independent
     * metadata writes are implemented, we will need to check for this property.
     */
    collective = TRUE;

    /* Start H5 operation */
    if(NULL == (int_req = H5_daos_req_create(item->file, H5I_INVALID_HID)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTALLOC, NULL, "can't create DAOS request");

#ifdef H5_DAOS_USE_TRANSACTIONS
    /* Start transaction */
    if(0 != (ret = daos_tx_open(item->file->coh, &int_req->th, NULL /*event*/)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't start transaction");
    int_req->th_open = TRUE;
#endif /* H5_DAOS_USE_TRANSACTIONS */

    /* Traverse the path */
    /* Call this on every rank for now so errors are handled correctly.  If/when
     * we add a bcast to check for failure we could only call this on the lead
     * rank. */
    if(name) {
        /* Queue traverse tasks */
        if(NULL == (target_obj = H5_daos_group_traverse(item, name, lcpl_id, int_req,
                collective, &path_buf, &target_name, &target_name_len, &first_task,
                &dep_task)))
            D_GOTO_ERROR(H5E_SYM, H5E_BADITER, NULL, "can't traverse path");

        /* Check type of target_obj */
        if(target_obj->item.type != H5I_GROUP)
            D_GOTO_ERROR(H5E_ARGS, H5E_BADTYPE, NULL, "target object is not a group");

        /* Reject invalid object names during object creation - if a name is
         * given it must parse to a link name that can be created */
        if(target_name_len == 0)
            D_GOTO_ERROR(H5E_SYM, H5E_BADVALUE, NULL, "path given does not resolve to a final link name");
    } /* end if */

    /* Create group and link to group */
    if(NULL == (grp = (H5_daos_group_t *)H5_daos_group_create_helper(item->file, FALSE,
            gcpl_id, gapl_id, (H5_daos_group_t *)target_obj, target_name,
            target_name_len, collective, int_req, &first_task, &dep_task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create group");

    /* Set return value */
    ret_value = (void *)grp;

done:
    /* Close target object */
    if(target_obj && H5_daos_object_close(target_obj, dxpl_id, NULL) < 0)
        D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close object");

    if(int_req) {
        /* Free path_buf if necessary */
        if(path_buf && H5_daos_free_async(item->file, path_buf, &first_task, &dep_task) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTFREE, NULL, "can't free path buffer");

        /* Create task to finalize H5 operation */
        if(0 != (ret = tse_task_create(H5_daos_h5op_finalize, &item->file->sched, int_req, &int_req->finalize_task)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        /* Register dependency (if any) */
        else if(dep_task && 0 != (ret = tse_task_register_deps(int_req->finalize_task, 1, &dep_task)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create dependencies for task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        /* Schedule finalize task */
        else if(0 != (ret = tse_task_schedule(int_req->finalize_task, false)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't schedule task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        else
            /* finalize_task now owns a reference to req */
            int_req->rc++;

        /* If there was an error during setup, pass it to the request */
        if(NULL == ret_value)
            int_req->status = -H5_DAOS_SETUP_ERROR;

        /* Schedule first task */
        if(first_task && (0 != (ret = tse_task_schedule(first_task, false))))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't schedule initial task for H5 operation: %s", H5_daos_err_to_string(ret));

        /* Block until operation completes */
        if(H5_daos_progress(&item->file->sched, int_req, H5_DAOS_PROGRESS_WAIT) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't progress scheduler");

        /* Check for failure */
        if(int_req->status < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTOPERATE, NULL, "group creation failed in task \"%s\": %s", int_req->failed_task, H5_daos_err_to_string(int_req->status));

        /* Close internal request */
        if(H5_daos_req_free_int(int_req) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't free request");
    } /* end if */

    /* Cleanup on failure */
    /* Destroy DAOS object if created before failure DSINC */
    if(NULL == ret_value)
        /* Close group */
        if(grp && H5_daos_group_close(grp, dxpl_id, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close group");

    D_FUNC_LEAVE_API;
} /* end H5_daos_group_create() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_open_bcast_comp_cb
 *
 * Purpose:     Complete callback for asynchronous MPI_ibcast for group
 *              opens (rank 0).
 *
 * Return:      Success:        0
 *              Failure:        Error code
 *
 * Programmer:  Neil Fortner
 *              January, 2020
 *
 *-------------------------------------------------------------------------
 */
static int
H5_daos_group_open_bcast_comp_cb(tse_task_t *task, void H5VL_DAOS_UNUSED *args)
{
    H5_daos_mpi_ibcast_ud_t *udata;
    int ret;
    int ret_value = 0;

    /* Get private data */
    if(NULL == (udata = tse_task_get_priv(task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_DAOS_GET_ERROR, "can't get private data for group info broadcast task");

    assert(udata->req);
    assert(udata->obj);
    assert(udata->obj->item.file);
    assert(!udata->obj->item.file->closed);
    assert(udata->obj->item.file->my_rank == 0);
    assert(udata->obj->item.type == H5I_GROUP);

    /* Handle errors in bcast task.  Only record error in udata->req_status if
     * it does not already contain an error (it could contain an error if
     * another task this task is not dependent on also failed). */
    if(task->dt_result < -H5_DAOS_PRE_ERROR
            && udata->req->status >= -H5_DAOS_SHORT_CIRCUIT) {
        udata->req->status = task->dt_result;
        udata->req->failed_task = "MPI_Ibcast group info";
    } /* end if */
    else if(task->dt_result == 0)
        /* Reissue bcast if necesary */
        if(udata->buffer_len != udata->count) {
            tse_task_t *bcast_task;

            assert(udata->count == H5_DAOS_GINFO_BUF_SIZE);
            assert(udata->buffer_len > H5_DAOS_GINFO_BUF_SIZE);

            /* Use full buffer this time */
            udata->count = udata->buffer_len;

            /* Create task for second bcast */
            if(0 !=  (ret = tse_task_create(H5_daos_mpi_ibcast_task, &udata->obj->item.file->sched, udata, &bcast_task)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create task for second group info broadcast: %s", H5_daos_err_to_string(ret));

            /* Set callback functions for second bcast */
            if(0 != (ret = tse_task_register_cbs(bcast_task, NULL, NULL, 0, H5_daos_group_open_bcast_comp_cb, NULL, 0)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't register callbacks for second group info broadcast: %s", H5_daos_err_to_string(ret));

            /* Schedule second bcast and transfer ownership of udata */
            if(0 != (ret = tse_task_schedule(bcast_task, false)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't schedule task for second group info broadcast: %s", H5_daos_err_to_string(ret));
            udata = NULL;
        } /* end if */

done:
    /* Free private data if we haven't released ownership */
    if(udata) {
        /* Close group */
        if(H5_daos_group_close((H5_daos_group_t *)udata->obj, H5I_INVALID_HID, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_H5_CLOSE_ERROR, "can't close group");

        /* Handle errors in this function */
        /* Do not place any code that can issue errors after this block, except
         * for H5_daos_req_free_int, which updates req->status if it sees an
         * error */
        if(ret_value < -H5_DAOS_SHORT_CIRCUIT && udata->req->status >= -H5_DAOS_SHORT_CIRCUIT) {
            udata->req->status = ret_value;
            udata->req->failed_task = "MPI_Ibcast group info completion callback";
        } /* end if */

        /* Release our reference to req */
        if(H5_daos_req_free_int(udata->req) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_FREE_ERROR, "can't free request");

        /* Complete bcast metatask */
        tse_task_complete(udata->bcast_metatask, ret_value);

        /* Free buffer */
        DV_free(udata->buffer);

        /* Free private data */
        DV_free(udata);
    } /* end if */
    else
        assert(ret_value >= 0 || ret_value == -H5_DAOS_DAOS_GET_ERROR);

    return ret_value;
} /* end H5_daos_group_open_bcast_comp_cb() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_open_recv_comp_cb
 *
 * Purpose:     Complete callback for asynchronous MPI_ibcast for group
 *              opens (rank 1+).
 *
 * Return:      Success:        0
 *              Failure:        Error code
 *
 * Programmer:  Neil Fortner
 *              February, 2020
 *
 *-------------------------------------------------------------------------
 */
static int
H5_daos_group_open_recv_comp_cb(tse_task_t *task, void H5VL_DAOS_UNUSED *args)
{
    H5_daos_mpi_ibcast_ud_t *udata;
    int ret;
    int ret_value = 0;

    /* Get private data */
    if(NULL == (udata = tse_task_get_priv(task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_DAOS_GET_ERROR, "can't get private data for group info receive task");

    assert(udata->req);
    assert(udata->obj);
    assert(udata->obj->item.file);
    assert(!udata->req->file->closed);
    assert(udata->obj->item.file->my_rank > 0);
    assert(udata->obj->item.type == H5I_GROUP);

    /* Handle errors in bcast task.  Only record error in udata->req_status if
     * it does not already contain an error (it could contain an error if
     * another task this task is not dependent on also failed). */
    if(task->dt_result < -H5_DAOS_PRE_ERROR
            && udata->req->status >= -H5_DAOS_SHORT_CIRCUIT) {
        udata->req->status = task->dt_result;
        udata->req->failed_task = "MPI_Ibcast group info";
    } /* end if */
    else if(task->dt_result == 0) {
        uint64_t gcpl_len;
        size_t ginfo_len;
        uint8_t *p = udata->buffer;

        /* Decode oid */
        UINT64DECODE(p, udata->obj->oid.lo)
        UINT64DECODE(p, udata->obj->oid.hi)

        /* Decode GCPL length */
        UINT64DECODE(p, gcpl_len)

        /* Check for gcpl_len set to 0 - indicates failure */
        if(gcpl_len == 0)
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_REMOTE_ERROR, "lead process failed to open group");

        /* Calculate data length */
        ginfo_len = (size_t)gcpl_len + 3 * sizeof(uint64_t);

        /* Reissue bcast if necesary */
        if(ginfo_len > (size_t)udata->count) {
            tse_task_t *bcast_task;

            assert(udata->buffer_len == H5_DAOS_GINFO_BUF_SIZE);
            assert(udata->count == H5_DAOS_GINFO_BUF_SIZE);

            /* Realloc buffer */
            DV_free(udata->buffer);
            if(NULL == (udata->buffer = DV_malloc(ginfo_len)))
                D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, -H5_DAOS_ALLOC_ERROR, "failed to allocate memory for group info buffer");
            udata->buffer_len = ginfo_len;
            udata->count = ginfo_len;

            /* Create task for second bcast */
            if(0 !=  (ret = tse_task_create(H5_daos_mpi_ibcast_task, &udata->obj->item.file->sched, udata, &bcast_task)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create task for second group info broadcast: %s", H5_daos_err_to_string(ret));

            /* Set callback functions for second bcast */
            if(0 != (ret = tse_task_register_cbs(bcast_task, NULL, NULL, 0, H5_daos_group_open_recv_comp_cb, NULL, 0)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't register callbacks for second group info broadcast: %s", H5_daos_err_to_string(ret));

            /* Schedule second bcast and transfer ownership of udata */
            if(0 != (ret = tse_task_schedule(bcast_task, false)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't schedule task for second group info broadcast: %s", H5_daos_err_to_string(ret));
            udata = NULL;
        } /* end if */
        else {
            /* Finish building group object */
            /* Open group */
            if(0 != (ret = daos_obj_open(udata->obj->item.file->coh, udata->obj->oid, udata->obj->item.file->flags & H5F_ACC_RDWR ? DAOS_COO_RW : DAOS_COO_RO, &udata->obj->obj_oh, NULL /*event*/)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTOPENOBJ, ret, "can't open group: %s", H5_daos_err_to_string(ret));

            /* Decode GCPL */
            if((((H5_daos_group_t *)udata->obj)->gcpl_id = H5Pdecode(p)) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTDECODE, -H5_DAOS_H5_DECODE_ERROR, "can't deserialize GCPL");

            /* Fill GCPL cache */
            if(H5_daos_group_fill_gcpl_cache((H5_daos_group_t *)udata->obj) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_CPL_CACHE_ERROR, "failed to fill GCPL cache");

            /* Fill OCPL cache */
            if(H5_daos_fill_ocpl_cache(udata->obj, ((H5_daos_group_t *)udata->obj)->gcpl_id) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_CPL_CACHE_ERROR, "failed to fill OCPL cache");
        } /* end else */
    } /* end else */

done:
    /* Free private data if we haven't released ownership */
    if(udata) {
        /* Close group */
        if(H5_daos_group_close((H5_daos_group_t *)udata->obj, H5I_INVALID_HID, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_H5_CLOSE_ERROR, "can't close group");

        /* Handle errors in this function */
        /* Do not place any code that can issue errors after this block, except
         * for H5_daos_req_free_int, which updates req->status if it sees an
         * error */
        if(ret_value < -H5_DAOS_SHORT_CIRCUIT && udata->req->status >= -H5_DAOS_SHORT_CIRCUIT) {
            udata->req->status = ret_value;
            udata->req->failed_task = "MPI_Ibcast group info completion callback";
        } /* end if */

        /* Release our reference to req */
        if(H5_daos_req_free_int(udata->req) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_FREE_ERROR, "can't free request");

        /* Complete bcast metatask */
        tse_task_complete(udata->bcast_metatask, ret_value);

        /* Free buffer */
        DV_free(udata->buffer);

        /* Free private data */
        DV_free(udata);
    } /* end if */
    else
        assert(ret_value >= 0 || ret_value == -H5_DAOS_DAOS_GET_ERROR);

    return ret_value;
} /* end H5_daos_group_open_recv_comp_cb() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_ginfo_read_comp_cb
 *
 * Purpose:     Complete callback for asynchronous metadata fetch for
 *              group opens.
 *
 * Return:      Success:        0
 *              Failure:        Error code
 *
 * Programmer:  Neil Fortner
 *              February, 2020
 *
 *-------------------------------------------------------------------------
 */
static int
H5_daos_ginfo_read_comp_cb(tse_task_t *task, void H5VL_DAOS_UNUSED *args)
{
    H5_daos_omd_fetch_ud_t *udata;
    int ret;
    int ret_value = 0;

    /* Get private data */
    if(NULL == (udata = tse_task_get_priv(task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_DAOS_GET_ERROR, "can't get private data for group info read task");

    assert(udata->md_rw_cb_ud.req);
    assert(udata->md_rw_cb_ud.req->file);
    assert(udata->md_rw_cb_ud.obj);
    assert(udata->fetch_metatask);
    assert(!udata->md_rw_cb_ud.req->file->closed);
    assert(udata->md_rw_cb_ud.obj->item.type == H5I_GROUP);

    /* Check for buffer not large enough */
    if(task->dt_result == -DER_REC2BIG) {
        tse_task_t *fetch_task;

        if(udata->bcast_udata) {
            /* Verify iod size makes sense */
            if(udata->md_rw_cb_ud.sg_iov[0].iov_buf_len != (H5_DAOS_GINFO_BUF_SIZE - 3 * H5_DAOS_ENCODED_UINT64_T_SIZE))
                D_GOTO_ERROR(H5E_SYM, H5E_BADVALUE, -H5_DAOS_BAD_VALUE, "buffer length does not match expected value");
            if(udata->md_rw_cb_ud.iod[0].iod_size <= (H5_DAOS_GINFO_BUF_SIZE - 3 * H5_DAOS_ENCODED_UINT64_T_SIZE))
                D_GOTO_ERROR(H5E_SYM, H5E_BADVALUE, -H5_DAOS_BAD_VALUE, "invalid iod_size returned from DAOS (buffer should have been large enough)");
            
            /* Reallocate group info buffer */
            udata->bcast_udata->buffer = DV_free(udata->bcast_udata->buffer);
            if(NULL == (udata->bcast_udata->buffer = DV_malloc(udata->md_rw_cb_ud.iod[0].iod_size + 3 * H5_DAOS_ENCODED_UINT64_T_SIZE)))
                D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, -H5_DAOS_ALLOC_ERROR, "can't allocate buffer for serialized group info");
            udata->bcast_udata->buffer_len = udata->md_rw_cb_ud.iod[0].iod_size + 3 * H5_DAOS_ENCODED_UINT64_T_SIZE;

            /* Set up sgl */
            daos_iov_set(&udata->md_rw_cb_ud.sg_iov[0], (uint8_t *)udata->bcast_udata->buffer + 3 * H5_DAOS_ENCODED_UINT64_T_SIZE, udata->md_rw_cb_ud.iod[0].iod_size);
            udata->md_rw_cb_ud.sgl[0].sg_nr_out = 0;
        } /* end if */
        else {
            /* Verify iod size makes sense */
            if(udata->md_rw_cb_ud.sg_iov[0].iov_buf_len != H5_DAOS_GINFO_BUF_SIZE)
                D_GOTO_ERROR(H5E_SYM, H5E_BADVALUE, -H5_DAOS_BAD_VALUE, "buffer length does not match expected value");
            if(udata->md_rw_cb_ud.iod[0].iod_size <= H5_DAOS_GINFO_BUF_SIZE)
                D_GOTO_ERROR(H5E_SYM, H5E_BADVALUE, -H5_DAOS_BAD_VALUE, "invalid iod_size returned from DAOS (buffer should have been large enough)");
            
            /* Reallocate group info buffer */
            udata->md_rw_cb_ud.sg_iov[0].iov_buf = DV_free(udata->md_rw_cb_ud.sg_iov[0].iov_buf);
            if(NULL == (udata->md_rw_cb_ud.sg_iov[0].iov_buf = DV_malloc(udata->md_rw_cb_ud.iod[0].iod_size)))
                D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, -H5_DAOS_ALLOC_ERROR, "can't allocate buffer for serialized group info");

            /* Set up sgl */
            udata->md_rw_cb_ud.sg_iov[0].iov_buf_len = udata->md_rw_cb_ud.iod[0].iod_size;
            udata->md_rw_cb_ud.sg_iov[0].iov_len = udata->md_rw_cb_ud.iod[0].iod_size;
            udata->md_rw_cb_ud.sgl[0].sg_nr_out = 0;
        } /* end else */

        /* Create task for reissued group metadata read */
        if(0 != (ret = daos_task_create(DAOS_OPC_OBJ_FETCH, &udata->md_rw_cb_ud.obj->item.file->sched, 0, NULL, &fetch_task)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create task to read group medadata: %s", H5_daos_err_to_string(ret));

        /* Set callback functions for group metadata read */
        if(0 != (ret = tse_task_register_cbs(fetch_task, H5_daos_md_rw_prep_cb, NULL, 0, H5_daos_ginfo_read_comp_cb, NULL, 0)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't register callbacks for task to read group medadata: %s", H5_daos_err_to_string(ret));

        /* Set private data for group metadata read */
        (void)tse_task_set_priv(fetch_task, udata);

        /* Schedule group metadata read task and transfer ownership of udata */
        if(0 != (ret = tse_task_schedule(fetch_task, false)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't schedule task to read group metadata: %s", H5_daos_err_to_string(ret));
        udata = NULL;
    } /* end if */
    else {
        /* Handle errors in fetch task.  Only record error in udata->req_status
         * if it does not already contain an error (it could contain an error if
         * another task this task is not dependent on also failed). */
        if(task->dt_result < -H5_DAOS_PRE_ERROR
                && udata->md_rw_cb_ud.req->status >= -H5_DAOS_SHORT_CIRCUIT) {
            udata->md_rw_cb_ud.req->status = task->dt_result;
            udata->md_rw_cb_ud.req->failed_task = udata->md_rw_cb_ud.task_name;
        } /* end if */
        else if(task->dt_result == 0) {
            if(udata->bcast_udata) {
                uint8_t *p;

                /* Encode oid */
                p = udata->bcast_udata->buffer;
                UINT64ENCODE(p, udata->md_rw_cb_ud.obj->oid.lo)
                UINT64ENCODE(p, udata->md_rw_cb_ud.obj->oid.hi)

                /* Encode GCPL length */
                UINT64ENCODE(p, udata->md_rw_cb_ud.iod[0].iod_size)
                assert(p == udata->md_rw_cb_ud.sg_iov[0].iov_buf);
            } /* end if */

            /* Finish building group object */
            /* Decode GCPL */
            if((((H5_daos_group_t *)udata->md_rw_cb_ud.obj)->gcpl_id = H5Pdecode(udata->md_rw_cb_ud.sg_iov[0].iov_buf)) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTDECODE, -H5_DAOS_H5_DECODE_ERROR, "can't deserialize GCPL");

            /* Fill GCPL cache */
            if(H5_daos_group_fill_gcpl_cache((H5_daos_group_t *)udata->md_rw_cb_ud.obj) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_CPL_CACHE_ERROR, "failed to fill GCPL cache");

            /* Fill OCPL cache */
            if(H5_daos_fill_ocpl_cache(udata->md_rw_cb_ud.obj, ((H5_daos_group_t *)udata->md_rw_cb_ud.obj)->gcpl_id) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_CPL_CACHE_ERROR, "failed to fill OCPL cache");
        } /* end else */
    } /* end else */

done:
    /* Clean up if this is the last fetch task */
    if(udata) {
        /* Close group */
        if(H5_daos_group_close((H5_daos_group_t *)udata->md_rw_cb_ud.obj, H5I_INVALID_HID, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_H5_CLOSE_ERROR, "can't close group");

        if(udata->bcast_udata) {
            /* Clear broadcast buffer if there was an error */
            if(udata->md_rw_cb_ud.req->status < -H5_DAOS_INCOMPLETE)
                (void)memset(udata->bcast_udata->buffer, 0, H5_DAOS_GINFO_BUF_SIZE);
        } /* end if */
        else
            /* No broadcast, free buffer */
            DV_free(udata->md_rw_cb_ud.sg_iov[0].iov_buf);

        /* Handle errors in this function */
        /* Do not place any code that can issue errors after this block, except
         * for H5_daos_req_free_int, which updates req->status if it sees an
         * error */
        if(ret_value < -H5_DAOS_SHORT_CIRCUIT && udata->md_rw_cb_ud.req->status >= -H5_DAOS_SHORT_CIRCUIT) {
            udata->md_rw_cb_ud.req->status = ret_value;
            udata->md_rw_cb_ud.req->failed_task = udata->md_rw_cb_ud.task_name;
        } /* end if */

        /* Release our reference to req */
        if(H5_daos_req_free_int(udata->md_rw_cb_ud.req) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_FREE_ERROR, "can't free request");

        /* Complete fetch metatask */
        tse_task_complete(udata->fetch_metatask, ret_value);

        assert(!udata->md_rw_cb_ud.free_dkey);
        assert(!udata->md_rw_cb_ud.free_akeys);

        /* Free udata */
        DV_free(udata);
    } /* end if */
    else
        assert(ret_value == 0 || ret_value == -H5_DAOS_DAOS_GET_ERROR);

    return ret_value;
} /* end H5_daos_ginfo_read_comp_cb */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_open_helper
 *
 * Purpose:     Performs the actual group open. It is the responsibility
 *              of the calling function to make sure that the group's oid
 *              field is filled in before scheduled tasks are allowed to
 *              run.
 *
 * Return:      Success:        group object. 
 *              Failure:        NULL
 *
 * Programmer:  Neil Fortner
 *              December, 2016
 *
 *-------------------------------------------------------------------------
 */
H5_daos_group_t *
H5_daos_group_open_helper(H5_daos_file_t *file, hid_t gapl_id,
    hbool_t collective, H5_daos_req_t *req, tse_task_t **first_task,
    tse_task_t **dep_task)
{
    H5_daos_group_t *grp = NULL;
    uint8_t *ginfo_buf = NULL;
    H5_daos_mpi_ibcast_ud_t *bcast_udata = NULL;
    H5_daos_omd_fetch_ud_t *fetch_udata = NULL;
    int ret;
    H5_daos_group_t *ret_value = NULL;

    assert(file);
    assert(first_task);
    assert(dep_task);

    /* Allocate the group object that is returned to the user */
    if(NULL == (grp = H5FL_CALLOC(H5_daos_group_t)))
        D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "can't allocate DAOS group struct");
    grp->obj.item.type = H5I_GROUP;
    grp->obj.item.open_req = req;
    req->rc++;
    grp->obj.item.file = file;
    grp->obj.item.rc = 1;
    grp->obj.obj_oh = DAOS_HDL_INVAL;
    grp->gcpl_id = H5I_INVALID_HID;
    if((grp->gapl_id = H5Pcopy(gapl_id)) < 0)
        D_GOTO_ERROR(H5E_SYM, H5E_CANTCOPY, NULL, "failed to copy gapl");

    /* Set up broadcast user data */
    if(collective && (file->num_procs > 1)) {
        if(NULL == (bcast_udata = (H5_daos_mpi_ibcast_ud_t *)DV_malloc(sizeof(H5_daos_mpi_ibcast_ud_t))))
            D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "failed to allocate buffer for MPI broadcast user data");
        bcast_udata->req = req;
        bcast_udata->obj = &grp->obj;
        bcast_udata->sched = &file->sched;
        bcast_udata->buffer = NULL;
        bcast_udata->buffer_len = 0;
        bcast_udata->count = 0;
    } /* end if */

    /* Open group and read metadata if this process should */
    if(!collective || (file->my_rank == 0)) {
        tse_task_t *fetch_task = NULL;

        /* Open group object */
        if(H5_daos_obj_open(file, req, &grp->obj.oid, file->flags & H5F_ACC_RDWR ? DAOS_COO_RW : DAOS_COO_RO, &grp->obj.obj_oh, "group object open", first_task, dep_task) < 0)
            D_GOTO_ERROR(H5E_SYM, H5E_CANTOPENOBJ, NULL, "can't open group object");

        /* Allocate argument struct for fetch task */
        if(NULL == (fetch_udata = (H5_daos_omd_fetch_ud_t *)DV_calloc(sizeof(H5_daos_omd_fetch_ud_t))))
            D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "can't allocate buffer for fetch callback arguments");

        /* Set up operation to read GCPL size from group */
        /* Set up ud struct */
        fetch_udata->md_rw_cb_ud.req = req;
        fetch_udata->md_rw_cb_ud.obj = &grp->obj;
        fetch_udata->bcast_udata = bcast_udata;

        /* Set up dkey.  Point to global name buffer, do not free. */
        daos_iov_set(&fetch_udata->md_rw_cb_ud.dkey, (void *)H5_daos_int_md_key_g, H5_daos_int_md_key_size_g);
        fetch_udata->md_rw_cb_ud.free_dkey = FALSE;

        /* Single iod and sgl */
        fetch_udata->md_rw_cb_ud.nr = 1u;

        /* Set up iod.  Point akey to global name buffer, do not free. */
        daos_iov_set(&fetch_udata->md_rw_cb_ud.iod[0].iod_name, (void *)H5_daos_cpl_key_g, H5_daos_cpl_key_size_g);
        fetch_udata->md_rw_cb_ud.iod[0].iod_nr = 1u;
        fetch_udata->md_rw_cb_ud.iod[0].iod_size = DAOS_REC_ANY;
        fetch_udata->md_rw_cb_ud.iod[0].iod_type = DAOS_IOD_SINGLE;
        fetch_udata->md_rw_cb_ud.free_akeys = FALSE;

        /* Allocate initial group info buffer */
        if(NULL == (ginfo_buf = DV_malloc(H5_DAOS_GINFO_BUF_SIZE)))
            D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "can't allocate buffer for serialized gcpl");

        /* Set up sgl */
        if(bcast_udata) {
            daos_iov_set(&fetch_udata->md_rw_cb_ud.sg_iov[0], ginfo_buf + 3 * H5_DAOS_ENCODED_UINT64_T_SIZE, (daos_size_t)(H5_DAOS_GINFO_BUF_SIZE - 3 * H5_DAOS_ENCODED_UINT64_T_SIZE));
            bcast_udata->buffer = ginfo_buf;
            ginfo_buf = NULL;
            bcast_udata->buffer_len = H5_DAOS_GINFO_BUF_SIZE;
            bcast_udata->count = H5_DAOS_GINFO_BUF_SIZE;
        } /* end if */
        else
            daos_iov_set(&fetch_udata->md_rw_cb_ud.sg_iov[0], ginfo_buf, (daos_size_t)(H5_DAOS_GINFO_BUF_SIZE));
        fetch_udata->md_rw_cb_ud.sgl[0].sg_nr = 1;
        fetch_udata->md_rw_cb_ud.sgl[0].sg_nr_out = 0;
        fetch_udata->md_rw_cb_ud.sgl[0].sg_iovs = &fetch_udata->md_rw_cb_ud.sg_iov[0];

        /* Set task name */
        fetch_udata->md_rw_cb_ud.task_name = "group metadata read";

        /* Create meta task for group metadata read.  This empty task will be
         * completed when the read is finished by H5_daos_ginfo_read_comp_cb.
         * We can't use fetch_task since it may not be completed by the first
         * fetch. */
        if(0 != (ret = tse_task_create(NULL, &file->sched, NULL, &fetch_udata->fetch_metatask)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create meta task for group metadata read: %s", H5_daos_err_to_string(ret));

        /* Create task for group metadata read */
        assert(*dep_task);
        if(0 != (ret = daos_task_create(DAOS_OPC_OBJ_FETCH, &file->sched, 1, dep_task, &fetch_task)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create task to read group medadata: %s", H5_daos_err_to_string(ret));

        /* Set callback functions for group metadata read */
        if(0 != (ret = tse_task_register_cbs(fetch_task, H5_daos_md_rw_prep_cb, NULL, 0, H5_daos_ginfo_read_comp_cb, NULL, 0)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't register callbacks for task to read group medadata: %s", H5_daos_err_to_string(ret));

        /* Set private data for group metadata read */
        (void)tse_task_set_priv(fetch_task, fetch_udata);

        /* Schedule meta task */
        if(0 != (ret = tse_task_schedule(fetch_udata->fetch_metatask, false)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't schedule meta task for group metadata read: %s", H5_daos_err_to_string(ret));

        /* Schedule group metadata read task (or save it to be scheduled later)
         * and give it a reference to req and the group */
        assert(*first_task);
        if(0 != (ret = tse_task_schedule(fetch_task, false)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't schedule task to read group metadata: %s", H5_daos_err_to_string(ret));
        *dep_task = fetch_udata->fetch_metatask;
        req->rc++;
        grp->obj.item.rc++;
        fetch_udata = NULL;
        ginfo_buf = NULL;
    } /* end if */
    else {
        assert(bcast_udata);

        /* Allocate buffer for group info */
        if(NULL == (bcast_udata->buffer = DV_malloc(H5_DAOS_GINFO_BUF_SIZE)))
            D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, NULL, "can't allocate buffer for serialized gcpl");
        bcast_udata->buffer_len = H5_DAOS_GINFO_BUF_SIZE;
        bcast_udata->count = H5_DAOS_GINFO_BUF_SIZE;
    } /* end else */

    ret_value = grp;

done:
    /* Broadcast group info */
    if(bcast_udata) {
        assert(!ginfo_buf);
        if(H5_daos_mpi_ibcast(bcast_udata, &file->sched, &grp->obj, H5_DAOS_GINFO_BUF_SIZE,
                NULL == ret_value ? TRUE : FALSE, NULL,
                file->my_rank == 0 ? H5_daos_group_open_bcast_comp_cb : H5_daos_group_open_recv_comp_cb,
                req, first_task, dep_task) < 0) {
            DV_free(bcast_udata->buffer);
            DV_free(bcast_udata);
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "failed to broadcast group info buffer");
        } /* end if */

        bcast_udata = NULL;
    } /* end if */

    /* Cleanup on failure */
    if(NULL == ret_value) {
        /* Close group */
        if(grp && H5_daos_group_close(grp, req->dxpl_id, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close group");

        /* Free memory */
        fetch_udata = DV_free(fetch_udata);
        ginfo_buf = DV_free(ginfo_buf);
    } /* end if */

    /* Make sure we cleaned up */
    assert(!fetch_udata);
    assert(!bcast_udata);
    assert(!ginfo_buf);

    D_FUNC_LEAVE;
} /* end H5_daos_group_open_helper() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_open_int
 *
 * Purpose:     Internal version of H5_daos_group_open
 *
 * Return:      Success:        group object. 
 *              Failure:        NULL
 *
 * Programmer:  Neil Fortner
 *              November, 2016
 *
 *-------------------------------------------------------------------------
 */
H5_daos_group_t *
H5_daos_group_open_int(H5_daos_item_t *item,
    const H5VL_loc_params_t *loc_params, const char *name, hid_t gapl_id,
    H5_daos_req_t *req, hbool_t collective, tse_task_t **first_task,
    tse_task_t **dep_task)
{
    H5_daos_group_t *grp = NULL;
    H5_daos_obj_t *target_obj = NULL;
    daos_obj_id_t oid = {0, 0};
    daos_obj_id_t **oid_ptr = NULL;
    char *path_buf = NULL;
    hbool_t must_bcast = FALSE;
    H5_daos_group_t *ret_value = NULL;

    assert(item);
    assert(loc_params);
    assert(req);
    assert(req->dxpl_id >= 0);
    assert(first_task);
    assert(dep_task);

    /* Check for open by object token */
    if(H5VL_OBJECT_BY_TOKEN == loc_params->type) {
        /* Generate oid from token */
        if(H5_daos_token_to_oid(loc_params->loc_data.loc_by_token.token, &oid) < 0)
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't convert object token to OID");
    } /* end if */
    else {
        const char *target_name = NULL;
        size_t target_name_len;

        /* Open using name parameter */
        if(H5VL_OBJECT_BY_SELF != loc_params->type)
            D_GOTO_ERROR(H5E_ARGS, H5E_UNSUPPORTED, NULL, "unsupported group open location parameters type");
        if(!name)
            D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, NULL, "group name is NULL");

        /* At this point we must broadcast on failure */
        if(collective && (item->file->num_procs > 1))
            must_bcast = TRUE;

        /* Traverse the path */
        if(NULL == (target_obj = H5_daos_group_traverse(item, name, H5P_LINK_CREATE_DEFAULT,
                req, collective, &path_buf, &target_name, &target_name_len, first_task, dep_task)))
            D_GOTO_ERROR(H5E_SYM, H5E_BADITER, NULL, "can't traverse path");

        /* Check type of target_obj */
        if(target_obj->item.type != H5I_GROUP)
            D_GOTO_ERROR(H5E_ARGS, H5E_BADTYPE, NULL, "target object is not a group");

        /* Check for no target_name, in this case just return target_grp */
        if(target_name_len == 0) {
            /* Take ownership of target_obj */
            grp = (H5_daos_group_t *)target_obj;
            target_obj = NULL;

            /* No need to bcast since everyone just opened the already open
             * group */
            must_bcast = FALSE;
        } /* end if */
        else if(!collective || (item->file->my_rank == 0)) {
            /* Follow link to group */
            if(H5_daos_link_follow((H5_daos_group_t *)target_obj, target_name, target_name_len, FALSE,
                    req, &oid_ptr, NULL, first_task, dep_task) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_TRAVERSE, NULL, "can't follow link to group");
        } /* end else */
    } /* end else */

    /* Open group if not already open */
    if(!grp) {
        must_bcast = FALSE;     /* Helper function will handle bcast */
        if(NULL == (grp = H5_daos_group_open_helper(item->file, gapl_id,
                collective, req, first_task, dep_task)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTOPENOBJ, NULL, "can't open group");

        /* Set group oid */
        if(oid_ptr)
            /* Retarget *oid_ptr to grp->obj.oid so H5_daos_link_follow fills in
             * the group's oid */
            *oid_ptr = &grp->obj.oid;
        else if(H5VL_OBJECT_BY_TOKEN == loc_params->type)
            /* Just set the static oid from the token */
            grp->obj.oid = oid;
        else
            /* We will receive oid from lead process */
            assert(collective && item->file->my_rank > 0);
    } /* end if */

    /* Set return value */
    ret_value = grp;

done:
    /* Free path_buf if necessary */
    if(path_buf && H5_daos_free_async(item->file, path_buf, first_task, dep_task) < 0)
        D_DONE_ERROR(H5E_SYM, H5E_CANTFREE, NULL, "can't free path buffer");

    /* Close target object */
    if(target_obj && H5_daos_object_close(target_obj, req->dxpl_id, NULL) < 0)
        D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close object");

    /* Cleanup on failure */
    if(NULL == ret_value) {
        /* Broadcast failure */
        if(must_bcast && H5_daos_mpi_ibcast(NULL, &item->file->sched, &grp->obj, H5_DAOS_GINFO_BUF_SIZE,
                TRUE, NULL, item->file->my_rank == 0 ? H5_daos_group_open_bcast_comp_cb : H5_daos_group_open_recv_comp_cb,
                req, first_task, dep_task) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "failed to broadcast empty group info buffer to signal failure");
        must_bcast = FALSE;

        /* Close group to prevent memory leaks since we're not returning it */
        if(grp && H5_daos_group_close(grp, req->dxpl_id, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close group");
    } /* end if */

    assert(!must_bcast);

    D_FUNC_LEAVE;
} /* end H5_daos_group_open_int() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_open
 *
 * Purpose:     Sends a request to DAOS to open a group
 *
 * Return:      Success:        group object.
 *              Failure:        NULL
 *
 * Programmer:  Neil Fortner
 *              November, 2016
 *
 *-------------------------------------------------------------------------
 */
void *
H5_daos_group_open(void *_item, const H5VL_loc_params_t *loc_params,
    const char *name, hid_t gapl_id, hid_t dxpl_id, void H5VL_DAOS_UNUSED **req)
{
    H5_daos_item_t *item = (H5_daos_item_t *)_item;
    H5_daos_group_t *grp = NULL;
    hbool_t collective;
    H5_daos_req_t *int_req = NULL;
    tse_task_t *first_task = NULL;
    tse_task_t *dep_task = NULL;
    int ret;
    void *ret_value = NULL;

    if(!_item)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, NULL, "group parent object is NULL");
    if(!loc_params)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, NULL, "location parameters object is NULL");

    /*
     * Like HDF5, metadata reads are independent by default. If the application has specifically
     * requested collective metadata reads, they will be enabled here.
     */
    collective = item->file->fapl_cache.is_collective_md_read;
    if(!collective && (H5P_GROUP_ACCESS_DEFAULT != gapl_id))
        if(H5Pget_all_coll_metadata_ops(gapl_id, &collective) < 0)
            D_GOTO_ERROR(H5E_SYM, H5E_CANTGET, NULL, "can't get collective metadata reads property");

    /* Start H5 operation */
    if(NULL == (int_req = H5_daos_req_create(item->file, dxpl_id)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTALLOC, NULL, "can't create DAOS request");

#ifdef H5_DAOS_USE_TRANSACTIONS
    /* Start transaction */
    if(0 != (ret = daos_tx_open(item->file->coh, &int_req->th, NULL /*event*/)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't start transaction");
    int_req->th_open = TRUE;
#endif /* H5_DAOS_USE_TRANSACTIONS */

    /* Call internal open routine */
    if(NULL == (grp = H5_daos_group_open_int(item, loc_params, name, gapl_id,
            int_req, collective, &first_task, &dep_task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTOPENOBJ, NULL, "can't open group");

    /* Set return value */
    ret_value = (void *)grp;

done:
    if(int_req) {
        /* Create task to finalize H5 operation */
        if(0 != (ret = tse_task_create(H5_daos_h5op_finalize, &item->file->sched, int_req, &int_req->finalize_task)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        /* Register dependency (if any) */
        else if(dep_task && 0 != (ret = tse_task_register_deps(int_req->finalize_task, 1, &dep_task)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't create dependencies for task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        /* Schedule finalize task */
        else if(0 != (ret = tse_task_schedule(int_req->finalize_task, false)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't schedule task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        else
            /* finalize_task now owns a reference to req */
            int_req->rc++;

        /* If there was an error during setup, pass it to the request */
        if(NULL == ret_value)
            int_req->status = -H5_DAOS_SETUP_ERROR;

        /* Schedule first task */
        if(first_task && (0 != (ret = tse_task_schedule(first_task, false))))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't schedule initial task for H5 operation: %s", H5_daos_err_to_string(ret));

        /* Block until operation completes */
        if(H5_daos_progress(&item->file->sched, int_req, H5_DAOS_PROGRESS_WAIT) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, NULL, "can't progress scheduler");

        /* Check for failure */
        if(int_req->status < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTOPERATE, NULL, "group open failed in task \"%s\": %s", int_req->failed_task, H5_daos_err_to_string(int_req->status));

        /* Close internal request */
        if(H5_daos_req_free_int(int_req) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't free request");
    } /* end if */

    /* If we are not returning a group we must close it */
    if(ret_value == NULL && grp && H5_daos_group_close(grp, dxpl_id, NULL) < 0)
        D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, NULL, "can't close group");

    D_FUNC_LEAVE_API;
} /* end H5_daos_group_open() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_get
 *
 * Purpose:     Performs a group "get" operation
 *
 * Return:      Success:        0
 *              Failure:        -1
 *
 * Programmer:  Jordan Henderson
 *              January, 2019
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5_daos_group_get(void *_item, H5VL_group_get_t get_type, hid_t dxpl_id,
    void H5VL_DAOS_UNUSED **req, va_list arguments)
{
    H5_daos_group_t *grp = (H5_daos_group_t *)_item;
    H5_daos_req_t   *int_req = NULL;
    tse_task_t      *first_task = NULL;
    tse_task_t      *dep_task = NULL;
    int              ret;
    herr_t           ret_value = SUCCEED;

    if(!_item)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "VOL object is NULL");
    if(H5I_FILE != grp->obj.item.type && H5I_GROUP != grp->obj.item.type)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "object is not a file or group");

    /* Start H5 operation */
    if(NULL == (int_req = H5_daos_req_create(grp->obj.item.file, dxpl_id)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTALLOC, FAIL, "can't create DAOS request");

#ifdef H5_DAOS_USE_TRANSACTIONS
    /* Start transaction */
    if(0 != (ret = daos_tx_open(grp->obj.item.file->coh, &int_req->th, NULL /*event*/)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't start transaction");
    int_req->th_open = TRUE;
#endif /* H5_DAOS_USE_TRANSACTIONS */

    switch (get_type) {
        /* H5Gget_create_plist */
        case H5VL_GROUP_GET_GCPL:
        {
            hid_t *ret_id = va_arg(arguments, hid_t *);

            if((*ret_id = H5Pcopy(grp->gcpl_id)) < 0)
                D_GOTO_ERROR(H5E_PLIST, H5E_CANTCOPY, FAIL, "can't get group's GCPL");

            /* Set group's object class on gcpl */
            if(H5_daos_set_oclass_from_oid(*ret_id, grp->obj.oid) < 0)
                D_GOTO_ERROR(H5E_PLIST, H5E_CANTSET, FAIL, "can't set object class property");

            break;
        } /* H5VL_GROUP_GET_GCPL */

        /* H5Gget_info(_by_name/by_idx) */
        case H5VL_GROUP_GET_INFO:
        {
            const H5VL_loc_params_t *loc_params = va_arg(arguments, const H5VL_loc_params_t *);
            H5G_info_t *group_info = va_arg(arguments, H5G_info_t *);

            if(H5_daos_group_get_info(grp, loc_params, group_info, int_req, &first_task, &dep_task) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTGET, FAIL, "can't get group's info");

            break;
        } /* H5VL_GROUP_GET_INFO */

        default:
            D_GOTO_ERROR(H5E_VOL, H5E_UNSUPPORTED, FAIL, "invalid or unsupported group get operation");
    } /* end switch */

done:
    if(int_req) {
        /* Create task to finalize H5 operation */
        if(0 != (ret = tse_task_create(H5_daos_h5op_finalize, &grp->obj.item.file->sched, int_req, &int_req->finalize_task)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't create task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        /* Register dependencies (if any) */
        else if(dep_task && 0 != (ret = tse_task_register_deps(int_req->finalize_task, 1, &dep_task)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't create dependencies for task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        /* Schedule finalize task */
        else if(0 != (ret = tse_task_schedule(int_req->finalize_task, false)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't schedule task to finalize H5 operation: %s", H5_daos_err_to_string(ret));
        else
            /* finalize_task now owns a reference to req */
            int_req->rc++;

        /* If there was an error during setup, pass it to the request */
        if(ret_value < 0)
            int_req->status = -H5_DAOS_SETUP_ERROR;

        /* Schedule first_task */
        if(first_task && (0 != (ret = tse_task_schedule(first_task, false))))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't schedule first task: %s", H5_daos_err_to_string(ret));

        /* Block until operation completes */
        if(H5_daos_progress(&grp->obj.item.file->sched, int_req, H5_DAOS_PROGRESS_WAIT) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't progress scheduler");

        /* Check for failure */
        if(int_req->status < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTOPERATE, FAIL, "group get operation failed in task \"%s\": %s", int_req->failed_task, H5_daos_err_to_string(int_req->status));

        /* Close internal request */
        if(H5_daos_req_free_int(int_req) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, FAIL, "can't free request");
    } /* end if */

    D_FUNC_LEAVE_API;
} /* end H5_daos_group_get() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_specific
 *
 * Purpose:     Performs a group "specific" operation
 *
 * Return:      Success:        0
 *              Failure:        -1
 *
 * Programmer:  Jordan Henderson
 *              January, 2019
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5_daos_group_specific(void *_item, H5VL_group_specific_t specific_type,
    hid_t H5VL_DAOS_UNUSED dxpl_id, void H5VL_DAOS_UNUSED **req, va_list H5VL_DAOS_UNUSED arguments)
{
    H5_daos_group_t *grp = (H5_daos_group_t *)_item;
    herr_t           ret_value = SUCCEED;

    if(!_item)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "VOL object is NULL");
    if(H5I_FILE != grp->obj.item.type && H5I_GROUP != grp->obj.item.type)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "object is not a file or group");

    switch (specific_type) {
        /* H5Gflush */
        case H5VL_GROUP_FLUSH:
            if(H5_daos_group_flush(grp) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_WRITEERROR, FAIL, "can't flush group");
            break;

        /* H5Grefresh */
        case H5VL_GROUP_REFRESH:
            if(H5_daos_group_refresh(grp, dxpl_id, req) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTOPERATE, FAIL, "can't refresh group");
            break;

        default:
            D_GOTO_ERROR(H5E_VOL, H5E_UNSUPPORTED, FAIL, "invalid or unsupported group specific operation");
    } /* end switch */

done:
    D_FUNC_LEAVE_API;
} /* end H5_daos_group_specific() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_close
 *
 * Purpose:     Closes a daos HDF5 group.
 *
 * Return:      Success:        0
 *              Failure:        -1
 *
 * Programmer:  Neil Fortner
 *              November, 2016
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5_daos_group_close(void *_grp, hid_t H5VL_DAOS_UNUSED dxpl_id,
    void H5VL_DAOS_UNUSED **req)
{
    H5_daos_group_t *grp = (H5_daos_group_t *)_grp;
    int ret;
    herr_t ret_value = SUCCEED;

    if(!_grp)
        D_GOTO_ERROR(H5E_ARGS, H5E_BADVALUE, FAIL, "group object is NULL");

    if(--grp->obj.item.rc == 0) {
        /* Free group data structures */
        if(grp->obj.item.open_req)
            if(H5_daos_req_free_int(grp->obj.item.open_req) < 0)
                D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, FAIL, "can't free request");
        if(!daos_handle_is_inval(grp->obj.obj_oh))
            if(0 != (ret = daos_obj_close(grp->obj.obj_oh, NULL /*event*/)))
                D_DONE_ERROR(H5E_SYM, H5E_CANTCLOSEOBJ, FAIL, "can't close group DAOS object: %s", H5_daos_err_to_string(ret));
        if(grp->gcpl_id != H5I_INVALID_HID && H5Idec_ref(grp->gcpl_id) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTDEC, FAIL, "failed to close gcpl");
        if(grp->gapl_id != H5I_INVALID_HID && H5Idec_ref(grp->gapl_id) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTDEC, FAIL, "failed to close gapl");
        grp = H5FL_FREE(H5_daos_group_t, grp);
    } /* end if */

done:
    D_FUNC_LEAVE_API;
} /* end H5_daos_group_close() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_flush
 *
 * Purpose:     Flushes a DAOS group.  Currently a no-op, may create a
 *              snapshot in the future.
 *
 * Return:      Success:        0
 *              Failure:        -1
 *
 * Programmer:  Jordan Henderson
 *              February, 2019
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5_daos_group_flush(H5_daos_group_t *grp)
{
    herr_t ret_value = SUCCEED;    /* Return value */

    assert(grp);

    /* Nothing to do if no write intent */
    if(!(grp->obj.item.file->flags & H5F_ACC_RDWR))
        D_GOTO_DONE(SUCCEED);

    /* Progress scheduler until empty? DSINC */

done:
    D_FUNC_LEAVE;
} /* end H5_daos_group_flush() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_refresh
 *
 * Purpose:     Refreshes a DAOS group (currently a no-op)
 *
 * Return:      Success:        0
 *              Failure:        -1
 *
 * Programmer:  Jordan Henderson
 *              July, 2019
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5_daos_group_refresh(H5_daos_group_t H5VL_DAOS_UNUSED *grp, hid_t H5VL_DAOS_UNUSED dxpl_id,
    void H5VL_DAOS_UNUSED **req)
{
    herr_t ret_value = SUCCEED;

    assert(grp);

    D_GOTO_DONE(SUCCEED);

done:
    D_FUNC_LEAVE;
} /* end H5_daos_group_refresh() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_get_info_task
 *
 * Purpose:     Asynchronous task for H5_daos_group_get_info().  Executes
 *              once target_obj is valid.
 *
 * Return:      Success:        0
 *              Failure:        Negative
 *
 *-------------------------------------------------------------------------
 */
static int
H5_daos_group_get_info_task(tse_task_t *task)
{
    H5_daos_group_get_info_ud_t *udata = NULL;
    tse_task_t *metatask = NULL;
    tse_task_t *first_task = NULL;
    tse_task_t *dep_task = NULL;
    int ret;
    int ret_value = 0;

    /* Get private data */
    if(NULL == (udata = tse_task_get_priv(task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_DAOS_GET_ERROR, "can't get private data for group get info task");

    /* Handle errors in previous tasks */
    if(udata->req->status < -H5_DAOS_SHORT_CIRCUIT) {
        D_GOTO_DONE(-H5_DAOS_PRE_ERROR);
    } /* end if */
    else if(udata->req->status == -H5_DAOS_SHORT_CIRCUIT) {
        D_GOTO_DONE(-H5_DAOS_SHORT_CIRCUIT);
    } /* end if */

    /* Verify opened objec tis a group */
    if(udata->opened_type != H5I_GROUP)
        D_GOTO_ERROR(H5E_SYM, H5E_BADVALUE, FAIL, "opened object is not a group");

    /* Retrieve the group's info */
    udata->group_info->storage_type = H5G_STORAGE_TYPE_UNKNOWN;
    udata->group_info->nlinks = 0;
    udata->group_info->max_corder = 0;
    udata->group_info->mounted = FALSE; /* DSINC - will file mounting be supported? */

    /* Retrieve group's max creation order value */
    if(((H5_daos_group_t *)udata->target_obj)->gcpl_cache.track_corder) {
        /* DSINC - no check for overflow for max_corder! */
        if(H5_daos_group_get_max_crt_order((H5_daos_group_t *)udata->target_obj,
                (uint64_t *)&udata->group_info->max_corder, udata->req, &first_task, &dep_task) < 0)
            D_GOTO_ERROR(H5E_SYM, H5E_CANTGET, -H5_DAOS_DAOS_GET_ERROR, "can't get group's max creation order value");
    } /* end if */
    else
        udata->group_info->max_corder = -1;

    /* Retrieve the number of links in the group. */
    if(H5_daos_group_get_num_links((H5_daos_group_t *)udata->target_obj, &udata->group_info->nlinks, udata->req, &first_task, &dep_task) < 0)
        D_GOTO_ERROR(H5E_SYM, H5E_CANTGET, FAIL, "can't get the number of links in group");

done:
    /* Clean up */
    if(udata) {
        /* Create metatask to complete this task after dep_task if necessary */
        if(dep_task) {
            /* Create metatask */
            if(0 != (ret = tse_task_create(H5_daos_metatask_autocomp_other, &udata->target_obj->item.file->sched, task, &metatask))) {
                D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create metatask for group get info: %s", H5_daos_err_to_string(ret));
                metatask = NULL;
            } /* end if */
            else {
                /* Register task dependency */
                if(0 != (ret = tse_task_register_deps(metatask, 1, &dep_task)))
                    D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create dependencies for group get info metatask: %s", H5_daos_err_to_string(ret));

                /* Schedule metatask */
                assert(first_task);
                if(0 != (ret = tse_task_schedule(metatask, false)))
                    D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't schedule metatask for group get info: %s", H5_daos_err_to_string(ret));
            } /* end else */
        } /* end if */

        /* Schedule first task */
        if(first_task && 0 != (ret = tse_task_schedule(first_task, false)))
            D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't schedule initial task for group get info: %s", H5_daos_err_to_string(ret));

        /* Close target_obj */
        if(H5_daos_group_close((H5_daos_group_t *)udata->target_obj, H5I_INVALID_HID, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_H5_CLOSE_ERROR, "can't close group");
        udata->target_obj = NULL;

        /* Handle errors in this function */
        /* Do not place any code that can issue errors after this block, except for
         * H5_daos_req_free_int, which updates req->status if it sees an error */
        if(ret_value < -H5_DAOS_SHORT_CIRCUIT && udata->req->status >= -H5_DAOS_SHORT_CIRCUIT) {
            udata->req->status = ret_value;
            udata->req->failed_task = "group get info task";
        } /* end if */

        /* Release our reference to req */
        if(H5_daos_req_free_int(udata->req) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_FREE_ERROR, "can't free request");

        /* Free udata */
        udata = DV_free(udata);
    } /* end if */

    /* Complete task if necessary */
    if(!metatask)
        tse_task_complete(task, ret_value);

    D_FUNC_LEAVE;
} /* end H5_daos_group_get_info_task() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_get_info
 *
 * Purpose:     Retrieves a group's info, storing the results in the
 *              supplied H5G_info_t.
 *
 * Return:      Success:        0
 *              Failure:        -1
 *
 * Programmer:  Jordan Henderson
 *              February, 2019
 *
 *-------------------------------------------------------------------------
 */
static herr_t
H5_daos_group_get_info(H5_daos_group_t *grp, const H5VL_loc_params_t *loc_params,
    H5G_info_t *group_info, H5_daos_req_t *req, tse_task_t **first_task,
    tse_task_t **dep_task)
{
    H5_daos_group_get_info_ud_t *task_udata = NULL;
    tse_task_t *get_info_task = NULL;
    int ret;
    herr_t ret_value = SUCCEED;

    assert(grp);
    assert(loc_params);
    assert(group_info);

    /* Allocate task udata struct */
    if(NULL == (task_udata = (H5_daos_group_get_info_ud_t *)DV_calloc(sizeof(H5_daos_group_get_info_ud_t))))
        D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "can't allocate group get info user data");
    task_udata->req = req;
    task_udata->group_info = group_info;

    /* Determine the target group */
    switch (loc_params->type) {
        /* H5Gget_info */
        case H5VL_OBJECT_BY_SELF:
        {
            /* Use item as group, or the root group if item is a file */
            if(grp->obj.item.type == H5I_FILE)
                task_udata->target_obj = &((H5_daos_file_t *)grp)->root_grp->obj;
            else if(grp->obj.item.type == H5I_GROUP)
                task_udata->target_obj = &grp->obj;
            else
                D_GOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "item not a file or group");

            task_udata->target_obj->item.rc++;

            task_udata->opened_type = H5I_GROUP;

            break;
        } /* H5VL_OBJECT_BY_SELF */

        /* H5Gget_info_by_name */
        case H5VL_OBJECT_BY_NAME:
        {
            H5VL_loc_params_t sub_loc_params;

            /* Open target group */
            sub_loc_params.obj_type = grp->obj.item.type;
            sub_loc_params.type = H5VL_OBJECT_BY_SELF;
            if(NULL == (task_udata->target_obj = (H5_daos_obj_t *)H5_daos_group_open_int(&grp->obj.item, &sub_loc_params,
                    loc_params->loc_data.loc_by_name.name, H5P_GROUP_ACCESS_DEFAULT, req, FALSE,
                    first_task, dep_task)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTOPENOBJ, FAIL, "can't open group");

            task_udata->opened_type = H5I_GROUP;

            break;
        } /* H5VL_OBJECT_BY_NAME */

        /* H5Gget_info_by_idx */
        case H5VL_OBJECT_BY_IDX:
        {
            if(H5_daos_object_open_helper(&grp->obj.item, loc_params, &task_udata->opened_type,
                    FALSE, NULL, &task_udata->target_obj, req, first_task, dep_task) < 0)
                D_GOTO_ERROR(H5E_SYM, H5E_CANTOPENOBJ, FAIL, "can't open group");

            break;
        } /* H5VL_OBJECT_BY_IDX */

        case H5VL_OBJECT_BY_TOKEN:
        default:
            D_GOTO_ERROR(H5E_SYM, H5E_BADVALUE, FAIL, "invalid loc_params type");
    } /* end switch */

    /* Create task to finish this operation */
    if(0 !=  (ret = tse_task_create(H5_daos_group_get_info_task, &grp->obj.item.file->sched, task_udata, &get_info_task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't create task for group get info: %s", H5_daos_err_to_string(ret));

    /* Register task dependency */
    if(*dep_task && 0 != (ret = tse_task_register_deps(get_info_task, 1, dep_task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't create dependencies for group get info task: %s", H5_daos_err_to_string(ret));

    /* Schedule get info task (or save it to be scheduled later) and give it a
     * reference to req and udata */
    if(*first_task) {
        if(0 != (ret = tse_task_schedule(get_info_task, false)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't schedule task for group get info: %s", H5_daos_err_to_string(ret));
    } /* end if */
    else
        *first_task = get_info_task;
    *dep_task = get_info_task;
    req->rc++;
    task_udata = NULL;

done:
    /* Clean up */
    if(task_udata) {
        assert(ret_value < 0);

        if(task_udata->target_obj && H5_daos_object_close(task_udata->target_obj, req->dxpl_id, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CANTCLOSEOBJ, FAIL, "can't close object");

        task_udata = DV_free(task_udata);
    } /* end if */

    D_FUNC_LEAVE;
} /* end H5_daos_group_get_info() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_gnl_task
 *
 * Purpose:     Asynchronous task for H5_daos_group_get_num_links.
 *              Executes once target_grp is valid.
 *
 * Return:      Success:        The number of links within the group
 *              Failure:        Negative
 *
 *-------------------------------------------------------------------------
 */
static int
H5_daos_group_gnl_task(tse_task_t *task)
{
    H5_daos_group_gnl_ud_t *udata = NULL;
    hid_t target_grp_id = H5I_INVALID_HID;
    tse_task_t *first_task = NULL;
    tse_task_t *dep_task = NULL;
    hbool_t metatask_scheduled = FALSE;
    int ret;
    int ret_value = 0;

    /* Get private data */
    if(NULL == (udata = tse_task_get_priv(task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_DAOS_GET_ERROR, "can't get private data for get num links task");

    assert(udata->md_rw_cb_ud.obj->item.type == H5I_GROUP);

    /* Handle errors in previous tasks */
    if(udata->md_rw_cb_ud.req->status < -H5_DAOS_SHORT_CIRCUIT) {
        D_GOTO_DONE(-H5_DAOS_PRE_ERROR);
    } /* end if */
    else if(udata->md_rw_cb_ud.req->status == -H5_DAOS_SHORT_CIRCUIT) {
        D_GOTO_DONE(-H5_DAOS_SHORT_CIRCUIT);
    } /* end if */

    /* If creation order is tracked, read number of links directly, otherwise
     * iterate over links, counting them */
    if(((H5_daos_group_t *)udata->md_rw_cb_ud.obj)->gcpl_cache.track_corder) {
        tse_task_t *fetch_task = NULL;

        /* Read the "number of links" key from the target group */

        /* Set up dkey */
        daos_iov_set(&udata->md_rw_cb_ud.dkey, (void *)H5_daos_link_corder_key_g, H5_daos_link_corder_key_size_g);

        /* Set nr */
        udata->md_rw_cb_ud.nr = 1;

        /* Set up iod */
        daos_iov_set(&udata->md_rw_cb_ud.iod[0].iod_name, (void *)H5_daos_nlinks_key_g, H5_daos_nlinks_key_size_g);
        udata->md_rw_cb_ud.iod[0].iod_nr = 1u;
        udata->md_rw_cb_ud.iod[0].iod_size = (daos_size_t)H5_DAOS_ENCODED_NUM_LINKS_SIZE;
        udata->md_rw_cb_ud.iod[0].iod_type = DAOS_IOD_SINGLE;

        /* Set up sgl */
        daos_iov_set(&udata->md_rw_cb_ud.sg_iov[0], udata->nlinks_buf, (daos_size_t)H5_DAOS_ENCODED_NUM_LINKS_SIZE);
        udata->md_rw_cb_ud.sgl[0].sg_nr = 1;
        udata->md_rw_cb_ud.sgl[0].sg_nr_out = 0;
        udata->md_rw_cb_ud.sgl[0].sg_iovs = &udata->md_rw_cb_ud.sg_iov[0];

        /* Do not free buffers */
        udata->md_rw_cb_ud.free_akeys = FALSE;
        udata->md_rw_cb_ud.free_dkey = FALSE;

        /* Set task name */
        udata->md_rw_cb_ud.task_name = "group get num links fetch";

        /* Create task for num links fetch */
        if(0 != (ret = daos_task_create(DAOS_OPC_OBJ_FETCH, &udata->md_rw_cb_ud.obj->item.file->sched, 0, NULL, &fetch_task)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create task to read num links: %s", H5_daos_err_to_string(ret));

        /* Set callback functions for name fetch */
        if(0 != (ret = tse_task_register_cbs(fetch_task, H5_daos_md_rw_prep_cb, NULL, 0, H5_daos_group_gnl_comp_cb, NULL, 0)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't register callbacks for task to get num links: %s", H5_daos_err_to_string(ret));

        /* Set private data for name fetch */
        (void)tse_task_set_priv(fetch_task, udata);

        /* Save fetch task to be scheduled later and transfer ownership of udata */
        assert(!first_task);
        first_task = fetch_task;
        udata = NULL;
    } /* end if */
    else {
        tse_task_t *metatask = NULL;
        H5_daos_iter_data_t iter_data;

        /* Iterate through links */

        /* Register id for grp */
        if((target_grp_id = H5VLwrap_register((H5_daos_group_t *)udata->md_rw_cb_ud.obj, H5I_GROUP)) < 0)
            D_GOTO_ERROR(H5E_ATOM, H5E_CANTREGISTER, FAIL, "unable to atomize object handle");
        udata->md_rw_cb_ud.obj->item.rc++;

        /* Initialize iteration data */
        H5_DAOS_ITER_DATA_INIT(iter_data, H5_DAOS_ITER_TYPE_LINK, H5_INDEX_NAME, H5_ITER_NATIVE,
                FALSE, NULL, target_grp_id, udata->nlinks, NULL, udata->md_rw_cb_ud.req);
        iter_data.u.link_iter_data.u.link_iter_op = H5_daos_link_iterate_count_links_callback;

        /* Retrieve the number of links in the group. */
        /* Note that all arguments to H5_daos_link_iterate have ref counts
         * incremented or are copied, so we can free udata in this function
         * without waiting */
        if(H5_daos_link_iterate((H5_daos_group_t *)udata->md_rw_cb_ud.obj, &iter_data, &first_task, &dep_task) < 0)
            D_GOTO_ERROR(H5E_SYM, H5E_CANTGET, FAIL, "can't retrieve the number of links in group");

        /* Create metatask to complete this task after dep_task if necessary */
        if(dep_task) {
            /* Create metatask */
            if(0 != (ret = tse_task_create(H5_daos_metatask_autocomp_other, &udata->md_rw_cb_ud.obj->item.file->sched, task, &metatask)))
                D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create metatask for group get num links: %s", H5_daos_err_to_string(ret));

            /* Register task dependency */
            if(dep_task && 0 != (ret = tse_task_register_deps(metatask, 1, &dep_task)))
                D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create dependencies for group get num links metatask: %s", H5_daos_err_to_string(ret));

            /* Schedule metatask */
            assert(first_task);
            if(0 != (ret = tse_task_schedule(metatask, false)))
                D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't schedule metatask for group get num links: %s", H5_daos_err_to_string(ret));
            metatask_scheduled = TRUE;
        } /* end if */
    } /* end else */

done:
    /* Schedule first task */
    if(first_task && 0 != (ret = tse_task_schedule(first_task, false)))
        D_DONE_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't schedule initial task for group get num links: %s", H5_daos_err_to_string(ret));

    /* Close group ID */
    if((target_grp_id >= 0) && (H5Idec_ref(target_grp_id) < 0))
        D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, FAIL, "can't close group ID");

    /* Cleanup udata if we still own it */
    if(udata) {
        /* Close target_grp */
        if(H5_daos_group_close((H5_daos_group_t *)udata->md_rw_cb_ud.obj, H5I_INVALID_HID, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_H5_CLOSE_ERROR, "can't close group");
        udata->md_rw_cb_ud.obj = NULL;

        /* Handle errors in this function */
        /* Do not place any code that can issue errors after this block, except for
         * H5_daos_req_free_int, which updates req->status if it sees an error */
        if(ret_value < -H5_DAOS_SHORT_CIRCUIT && udata->md_rw_cb_ud.req->status >= -H5_DAOS_SHORT_CIRCUIT) {
            udata->md_rw_cb_ud.req->status = ret_value;
            udata->md_rw_cb_ud.req->failed_task = "group get num links task";
        } /* end if */

        /* Release our reference to req */
        if(H5_daos_req_free_int(udata->md_rw_cb_ud.req) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_FREE_ERROR, "can't free request");

        /* Complete task if it's not being handled by the metatask */
        if(!metatask_scheduled)
            tse_task_complete(task, ret_value);

        /* Free udata */
        udata = DV_free(udata);
    } /* end if */
    else
        assert(ret_value >= 0 || ret_value == -H5_DAOS_DAOS_GET_ERROR);

    D_FUNC_LEAVE;
} /* end H5_daos_group_gnl_task() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_gnl_comp_cb
 *
 * Purpose:     Completion callback fo rgroup get num links fetch (from
 *              creation order data)
 *
 * Return:      Success:        0
 *              Failure:        Negative
 *
 *-------------------------------------------------------------------------
 */
static int
H5_daos_group_gnl_comp_cb(tse_task_t *task, void H5VL_DAOS_UNUSED *args)
{
    H5_daos_group_gnl_ud_t *udata = NULL;
    uint64_t nlinks64 = 0;
    uint8_t *p;
    int ret_value = 0;

    /* Get private data */
    if(NULL == (udata = tse_task_get_priv(task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_DAOS_GET_ERROR, "can't get private data for get num links task");

    /* Handle errors in fetch task.  Only record error in udata->req_status if
     * it does not already contain an error (it could contain an error if
     * another task this task is not dependent on also failed). */
    if(task->dt_result < -H5_DAOS_PRE_ERROR
            && udata->md_rw_cb_ud.req->status >= -H5_DAOS_SHORT_CIRCUIT) {
        udata->md_rw_cb_ud.req->status = task->dt_result;
        udata->md_rw_cb_ud.req->failed_task = udata->md_rw_cb_ud.task_name;
    } /* end if */
    else if(task->dt_result == 0) {
        p = udata->nlinks_buf;

        /* Check for no num links found, in this case it must be 0 */
        if(udata->md_rw_cb_ud.iod[0].iod_size == (uint64_t)0)
            nlinks64 = 0;
        else
            /* Decode num links */
            UINT64DECODE(p, nlinks64);

        /* Set output value */
        *udata->nlinks = (hsize_t)nlinks64;
    } /* end else */

    /* Complete main task */
    tse_task_complete(udata->gnl_task, ret_value);

    /* Close target_grp */
    if(H5_daos_group_close((H5_daos_group_t *)udata->md_rw_cb_ud.obj, H5I_INVALID_HID, NULL) < 0)
        D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_H5_CLOSE_ERROR, "can't close group");
    udata->md_rw_cb_ud.obj = NULL;

    /* Handle errors in this function */
    /* Do not place any code that can issue errors after this block, except for
     * H5_daos_req_free_int, which updates req->status if it sees an error */
    if(ret_value < -H5_DAOS_SHORT_CIRCUIT && udata->md_rw_cb_ud.req->status >= -H5_DAOS_SHORT_CIRCUIT) {
        udata->md_rw_cb_ud.req->status = ret_value;
        udata->md_rw_cb_ud.req->failed_task = "get group num links completion callback";
    } /* end if */

    /* Release our reference to req */
    if(H5_daos_req_free_int(udata->md_rw_cb_ud.req) < 0)
        D_DONE_ERROR(H5E_IO, H5E_CLOSEERROR, -H5_DAOS_FREE_ERROR, "can't free request");

    /* Free udata */
    udata = DV_free(udata);

done:
    D_FUNC_LEAVE;
} /* end H5_daos_group_gnl_comp_cb() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_get_num_links
 *
 * Purpose:     Retrieves the current number of links within the target
 *              group.  The fields within target_grp are not guaranteed to
 *              be valid until after *dep_task (as passed to this
 *              function) is complete.  *nlinks is not guaranteed to be
 *              valid until after *dep_task (as returned from this
 *              function) is complete.
 *
 * Return:      Success:        The number of links within the group
 *              Failure:        Negative
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5_daos_group_get_num_links(H5_daos_group_t *target_grp, hsize_t *nlinks,
    H5_daos_req_t *req, tse_task_t **first_task, tse_task_t **dep_task)
{
    H5_daos_group_gnl_ud_t *gnl_udata = NULL;
    int ret;
    herr_t ret_value = SUCCEED;

    assert(target_grp);
    H5daos_compile_assert(H5_DAOS_ENCODED_NUM_LINKS_SIZE == 8);

    /* Allocate task udata struct */
    if(NULL == (gnl_udata = (H5_daos_group_gnl_ud_t *)DV_calloc(sizeof(H5_daos_group_gnl_ud_t))))
        D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "can't allocate get num links user data");
    gnl_udata->md_rw_cb_ud.req = req;
    gnl_udata->md_rw_cb_ud.obj = &target_grp->obj;
    gnl_udata->nlinks = nlinks;

    /* Create task to finish this operation */
    if(0 !=  (ret = tse_task_create(H5_daos_group_gnl_task, &target_grp->obj.item.file->sched, gnl_udata, &gnl_udata->gnl_task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't create task for get num links: %s", H5_daos_err_to_string(ret));

    /* Register task dependency */
    if(*dep_task && 0 != (ret = tse_task_register_deps(gnl_udata->gnl_task, 1, dep_task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't create dependencies for get num links task: %s", H5_daos_err_to_string(ret));

    /* Schedule gnl task (or save it to be scheduled later) and give it a
     * reference to the group, req and udata */
    if(*first_task) {
        if(0 != (ret = tse_task_schedule(gnl_udata->gnl_task, false)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't schedule task for get num links: %s", H5_daos_err_to_string(ret));
    } /* end if */
    else
        *first_task = gnl_udata->gnl_task;
    *dep_task = gnl_udata->gnl_task;
    target_grp->obj.item.rc++;
    req->rc++;
    gnl_udata = NULL;

done:
    /* Clean up */
    if(gnl_udata) {
        assert(ret_value < 0);
        gnl_udata = DV_free(gnl_udata);
    } /* end if */

    D_FUNC_LEAVE;
} /* end H5_daos_group_get_num_links() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_gmco_comp_cb
 *
 * Purpose:     Completion callback for asynchronous fetch of group max
 *              creation order.
 *
 * Return:      Success:        0
 *              Failure:        Error code
 *
 *-------------------------------------------------------------------------
 */
static int
H5_daos_group_gmco_comp_cb(tse_task_t *task, void H5VL_DAOS_UNUSED *args)
{
    H5_daos_group_gmco_ud_t *udata = NULL;
    int ret_value = 0;

    /* Get private data */
    if(NULL == (udata = tse_task_get_priv(task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, -H5_DAOS_DAOS_GET_ERROR, "can't get private data for link get creation order by name task");

    /* Handle errors in fetch task.  Only record error in udata->req_status if
     * it does not already contain an error (it could contain an error if
     * another task this task is not dependent on also failed). */
    if(task->dt_result < -H5_DAOS_PRE_ERROR
            && udata->md_rw_cb_ud.req->status >= -H5_DAOS_SHORT_CIRCUIT) {
        udata->md_rw_cb_ud.req->status = task->dt_result;
        udata->md_rw_cb_ud.req->failed_task = udata->md_rw_cb_ud.task_name;
    } /* end if */
    else if(task->dt_result == 0) {
        /* Check that creation order is tracked for target group */
        /* Move this check to a custom prep cb? */
        if(!((H5_daos_group_t *)udata->md_rw_cb_ud.obj)->gcpl_cache.track_corder) {
            udata->md_rw_cb_ud.req->status = -H5_DAOS_BAD_VALUE;
            udata->md_rw_cb_ud.req->failed_task = udata->md_rw_cb_ud.task_name;
            D_GOTO_ERROR(H5E_SYM, H5E_BADVALUE, -H5_DAOS_BAD_VALUE, "creation order is not tracked for group");
        } /* end if */

        uint64_t max_corder_val;

        /* Check for no max creation order found, in this case it must be 0 */
        if(udata->md_rw_cb_ud.iod[0].iod_size == 0)
            max_corder_val = (uint64_t) 0;
        else {
            uint8_t *p;

            /* Decode max creation order */
            p = udata->max_corder_buf;
            UINT64DECODE(p, max_corder_val);
        } /* end else */

        /* Set output value */
        *udata->max_corder = max_corder_val;
    } /* end else */

done:
    /* Clean up */
    if(udata) {
        /* Close target_grp */
        if(H5_daos_group_close((H5_daos_group_t *)udata->md_rw_cb_ud.obj, H5I_INVALID_HID, NULL) < 0)
            D_DONE_ERROR(H5E_SYM, H5E_CLOSEERROR, -H5_DAOS_H5_CLOSE_ERROR, "can't close group");
        udata->md_rw_cb_ud.obj = NULL;

        /* Handle errors in this function */
        /* Do not place any code that can issue errors after this block, except for
         * H5_daos_req_free_int, which updates req->status if it sees an error */
        if(ret_value < -H5_DAOS_SHORT_CIRCUIT && udata->md_rw_cb_ud.req->status >= -H5_DAOS_SHORT_CIRCUIT) {
            udata->md_rw_cb_ud.req->status = ret_value;
            udata->md_rw_cb_ud.req->failed_task = "get link creation order by name completion callback";
        } /* end if */

        /* Release our reference to req */
        if(H5_daos_req_free_int(udata->md_rw_cb_ud.req) < 0)
            D_DONE_ERROR(H5E_IO, H5E_CLOSEERROR, -H5_DAOS_FREE_ERROR, "can't free request");

        /* Free udata */
        udata = DV_free(udata);
    } /* end if */

    D_FUNC_LEAVE;
} /* end H5_daos_group_gmco_comp_cb() */


/*-------------------------------------------------------------------------
 * Function:    H5_daos_group_get_max_crt_order
 *
 * Purpose:     Retrieves a group's current maximum creation order value.
 *              Note that this value may not match the current number of
 *              links within the group, as some of the links may have been
 *              deleted.
 *
 * Return:      Success:        0
 *              Failure:        -1
 *
 *-------------------------------------------------------------------------
 */
herr_t
H5_daos_group_get_max_crt_order(H5_daos_group_t *target_grp,
    uint64_t *max_corder, H5_daos_req_t *req, tse_task_t **first_task,
    tse_task_t **dep_task)
{
    H5_daos_group_gmco_ud_t *fetch_udata = NULL;
    tse_task_t *fetch_task = NULL;
    int ret;
    herr_t ret_value = SUCCEED;

    assert(target_grp);
    assert(max_corder);
    H5daos_compile_assert(H5_DAOS_ENCODED_CRT_ORDER_SIZE == 8);

    /* Allocate task udata struct */
    if(NULL == (fetch_udata = (H5_daos_group_gmco_ud_t *)DV_calloc(sizeof(H5_daos_group_gmco_ud_t))))
        D_GOTO_ERROR(H5E_RESOURCE, H5E_CANTALLOC, FAIL, "can't allocate get creation order by name user data");
    fetch_udata->md_rw_cb_ud.req = req;
    fetch_udata->md_rw_cb_ud.obj = &target_grp->obj;
    fetch_udata->max_corder = max_corder;

    /* Set up dkey */
    daos_iov_set(&fetch_udata->md_rw_cb_ud.dkey, (void *)H5_daos_link_corder_key_g, H5_daos_link_corder_key_size_g);

    /* Set nr */
    fetch_udata->md_rw_cb_ud.nr = 1;

    /* Set up iod */
    daos_iov_set(&fetch_udata->md_rw_cb_ud.iod[0].iod_name, (void *)H5_daos_max_link_corder_key_g, H5_daos_max_link_corder_key_size_g);
    fetch_udata->md_rw_cb_ud.iod[0].iod_nr = 1u;
    fetch_udata->md_rw_cb_ud.iod[0].iod_size = (daos_size_t)H5_DAOS_ENCODED_CRT_ORDER_SIZE;
    fetch_udata->md_rw_cb_ud.iod[0].iod_type = DAOS_IOD_SINGLE;

    /* Set up sgl */
    daos_iov_set(&fetch_udata->md_rw_cb_ud.sg_iov[0], fetch_udata->max_corder_buf, (daos_size_t)H5_DAOS_ENCODED_CRT_ORDER_SIZE);
    fetch_udata->md_rw_cb_ud.sgl[0].sg_nr = 1;
    fetch_udata->md_rw_cb_ud.sgl[0].sg_nr_out = 0;
    fetch_udata->md_rw_cb_ud.sgl[0].sg_iovs = &fetch_udata->md_rw_cb_ud.sg_iov[0];

    /* Do not free buffers */
    fetch_udata->md_rw_cb_ud.free_akeys = FALSE;
    fetch_udata->md_rw_cb_ud.free_dkey = FALSE;

    /* Set task name */
    fetch_udata->md_rw_cb_ud.task_name = "group get max creation order";

    /* Create task for max creation order fetch */
    if(0 != (ret = daos_task_create(DAOS_OPC_OBJ_FETCH, &fetch_udata->md_rw_cb_ud.obj->item.file->sched, 0, NULL, &fetch_task)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't create task to read max creation order: %s", H5_daos_err_to_string(ret));

    /* Set callback functions for max creation order fetch */
    if(0 != (ret = tse_task_register_cbs(fetch_task, H5_daos_md_rw_prep_cb, NULL, 0, H5_daos_group_gmco_comp_cb, NULL, 0)))
        D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, ret, "can't register callbacks for task to get max creation order: %s", H5_daos_err_to_string(ret));

    /* Set private data for max creation order fetch */
    (void)tse_task_set_priv(fetch_task, fetch_udata);

    /* Schedule fetch task (or save it to be scheduled later) and give it a
     * reference to the group, req and udata */
    if(*first_task) {
        if(0 != (ret = tse_task_schedule(fetch_task, false)))
            D_GOTO_ERROR(H5E_SYM, H5E_CANTINIT, FAIL, "can't schedule task for group get max creation order: %s", H5_daos_err_to_string(ret));
    } /* end if */
    else
        *first_task = fetch_task;
    *dep_task = fetch_task;
    target_grp->obj.item.rc++;
    req->rc++;
    fetch_udata = NULL;

done:
    /* Clean up */
    if(fetch_udata) {
        assert(ret_value < 0);
        fetch_udata = DV_free(fetch_udata);
    } /* end if */

    D_FUNC_LEAVE;
} /* end H5_daos_group_get_max_crt_order() */

